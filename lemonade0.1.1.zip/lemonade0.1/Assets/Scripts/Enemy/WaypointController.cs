﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaypointController : MonoBehaviour
{
	//patrol and follow player
	public List<Transform> waypoints = new List<Transform>();
	private Transform targetWaypoint;
	private int targetWaypointIndex = 0;
	private float minDistance = 0.1f;
	private int lastWaypointIndex;
	private float speed = 3.0f;
	private float rotationSpeed = 2.0f;
	private float inRange = 10.0f;
	private float escapeDistance = 12.0f;

	//approaching player
	public float stoppingDistance;
	public float retreatDistance;

	//shooting projectiles
	public Transform projectile;
	public float maximumAttackDistance = 30.0f;
	//public float maximumDistanceFromPlayer = 12.0f;
	public float shotInterval = 2f;
	private float shotTime = 0.0f;


	#region breadcrumb variables

	public enum EnemyState{
		PATROLING,
		FOLLOWING_PLAYER,
		FOLLOWING_BREADCRUMBS

	};

	EnemyState state = EnemyState.PATROLING;

	List<Transform> crumbs = new List<Transform>();
	public GameObject crumb;
	public Transform player;
	float minCrumbDistance = 3.0f;
	private Transform lastKnownWaypoint;

	#endregion

    // Start is called before the first frame update
    void Start()
    {
		lastWaypointIndex = waypoints.Count - 1;
		targetWaypoint = waypoints[targetWaypointIndex];
    }

    // Update is called once per frame
    void Update()
    {
		UpdateTransform();
		ControlEnemyState();
	}

	void ControlEnemyState()
	{
		CheckDistanceToPlayer();
		float distance = Vector3.Distance(transform.position, targetWaypoint.position);

		switch(state){

			case EnemyState.PATROLING:
				
				CheckDistanceToWaypoint(distance);
			break;

			case EnemyState.FOLLOWING_PLAYER:
				if(crumbs.Count >= 1){
					if(ShouldPlaceCrumb()){
						DropBreadCrumb();
					}
				}else{
					DropBreadCrumb();	
				}

				if(distance <= maximumAttackDistance && (Time.time - shotTime) > shotInterval){
					Shoot();
				}
				
				if(Vector3.Distance(transform.position, player.position) < stoppingDistance && Vector3.Distance(transform.position, player.position) > retreatDistance){
					transform.position = this.transform.position;
			}else	if(Vector3.Distance(transform.position, player.position) < retreatDistance){
				transform.position = Vector3.MoveTowards(transform.position, player.position, -speed * Time.deltaTime);
			}
				
			break;

			case EnemyState.FOLLOWING_BREADCRUMBS:
				ReturnToStartingPoint();
			break;

		}
	}

	bool ShouldPlaceCrumb()
	{
		if(Vector3.Distance(transform.position, crumbs[crumbs.Count - 1].transform.position) > minCrumbDistance){
			return true;
		}else{
			return false;
		}
	}

	void Shoot(){

		shotTime = Time.time;

		Instantiate(projectile, transform.position + (player.position - transform.position).normalized, Quaternion.LookRotation(player.position - transform.position));

	}

	void CheckDistanceToPlayer()
	{
		switch(state){

		case EnemyState.PATROLING:
			if(Vector3.Distance(transform.position, player.position) < inRange){

				lastKnownWaypoint = targetWaypoint;
				targetWaypoint = player.transform;
				state = EnemyState.FOLLOWING_PLAYER;

			}

		
		break;

		case EnemyState.FOLLOWING_PLAYER:
			//player escaped, follow breadcrumbs
			if(Vector3.Distance(transform.position, player.position) > escapeDistance){

				//lastKnownWaypoint = targetWaypoint;
				state = EnemyState.FOLLOWING_BREADCRUMBS;
			}
		break;

		case EnemyState.FOLLOWING_BREADCRUMBS:
			if(Vector3.Distance(transform.position, player.position) < inRange){
				targetWaypoint = player.transform;
				state = EnemyState.FOLLOWING_PLAYER;
			}
		break;

		}
	}

	private void DropBreadCrumb()
	{
		GameObject droppedCrumb = Instantiate(crumb, transform.position, Quaternion.identity, null);
		crumbs.Add(droppedCrumb.transform);
	}

	//called when enemy is following breadcrumbs
	void ReturnToStartingPoint()
	{
		//if there are still crumbs left to follow
		if(crumbs.Count >= 1){
			Transform lastCrumb = crumbs[crumbs.Count - 1];
			targetWaypoint = lastCrumb;

			if(Vector3.Distance(transform.position, lastKnownWaypoint.position) < Vector3.Distance(transform.position, targetWaypoint.position)){
				targetWaypoint = lastKnownWaypoint;
				state = EnemyState.PATROLING;

				foreach(Transform breadcrumb in crumbs){
					Destroy(breadcrumb.gameObject);
				}

				crumbs.Clear();
			}

			//reached the breadcrub
			if(Vector3.Distance(transform.position, targetWaypoint.position) < 0.3f){
				crumbs.Remove(lastCrumb.transform);
				Destroy(lastCrumb.gameObject);
				ReturnToStartingPoint();
			}
		}
		//no crumbs left
		else{
			state = EnemyState.PATROLING;
			targetWaypoint = lastKnownWaypoint;
		}
	}

	//updating rotation and position values
	void UpdateTransform()
	{
		float step = speed * Time.deltaTime;
		float rotationStep = rotationSpeed * Time.deltaTime;

		Vector3 directionToTarget = targetWaypoint.position - transform.position;
		Quaternion rotationToTarget = Quaternion.LookRotation(directionToTarget);

		transform.rotation = Quaternion.Slerp(transform.rotation, rotationToTarget, rotationStep);



		transform.position = Vector3.MoveTowards(transform.position, targetWaypoint.position, step);

	}


	void CheckDistanceToWaypoint(float currentDistance)
	{
		if(currentDistance <= minDistance){
			targetWaypointIndex++;
			UpdateTargetWaypoint();
		}
		
	}

	void UpdateTargetWaypoint()
	{
		if(targetWaypointIndex > lastWaypointIndex){
			targetWaypointIndex = 0;
		}
		targetWaypoint = waypoints[targetWaypointIndex];
	}
}
