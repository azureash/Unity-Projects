﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour
{
	//player.transform.position += camera.transform.forward.normalized;
	private Camera cam;

	public Rigidbody rigidbody;
	public Transform player;
	private float moveSpeed = 0.3f;

    // Start is called before the first frame update
    void Start()
    {
		cam = Camera.main;

		rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {

		if(Input.GetKey(KeyCode.S)){
			transform.position += -cam.transform.forward * moveSpeed;
			rigidbody.velocity = transform.position;
		} 

		else if(Input.GetKey(KeyCode.W)){
			transform.position += cam.transform.forward * moveSpeed;
			rigidbody.velocity = transform.position;

		}

		else if(Input.GetKey(KeyCode.A)){
			transform.position += -cam.transform.right * moveSpeed;
			rigidbody.velocity = transform.position;
		}

		else if(Input.GetKey(KeyCode.D)){
			transform.position += cam.transform.right * moveSpeed;
			rigidbody.velocity = transform.position;
		}

		transform.rotation = Quaternion.Slerp(player.transform.rotation, cam.transform.rotation, 1);
    }
}
