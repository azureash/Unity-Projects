﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour
{
	//player.transform.position += camera.transform.forward.normalized; ----FAÇA ESSE
	//GameCamera.transform.rotation ------exemplo

	private Camera cam;

    // Start is called before the first frame update
    void Start()
    {
		cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
		if(Input.GetKey(KeyCode.S)){
			transform.position += -cam.transform.forward.normalized;
		} 

		else if(Input.GetKey(KeyCode.W)){
			transform.position += cam.transform.forward.normalized;
		}

		else if(Input.GetKey(KeyCode.A)){
			transform.position += -cam.transform.right.normalized;
		}

		else if(Input.GetKey(KeyCode.D)){
			transform.position += cam.transform.right.normalized;
		}
    }
}
