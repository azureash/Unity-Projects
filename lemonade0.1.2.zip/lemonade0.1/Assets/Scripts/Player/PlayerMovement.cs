﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

	public float v, h;
	public Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
		v = Input.GetAxis("Vertical");
		h = Input.GetAxis("Horizontal");

		Animator(v, h);
    }

	void Animator(float v, float h)
	{
		anim.SetFloat("Forward", v);
		anim.SetFloat("Direction", h);
	}
}
